import apiClient from './client';

export const bankApi = {
    // 1. Проверить новые реальные транзакции (чтобы начислить МТКоины)
    // Игрок купил кофе -> нажал в игре "Синхронизировать" -> получил коины
    syncRealLifePurchases: async () => {
        try {
            const data = await apiClient.get('/bank/sync-mtcoins/');
            // Бэкенд возвращает сколько новых МТКоинов начислено
            return data;
        } catch (error) {
            console.error('Ошибка синхронизации транзакций:', error);
            throw error;
        }
    },

    // 2. Получить список доступных банковских наград (Синергия)
    getBankRewardsList: async () => {
        try {
            const data = await apiClient.get('/bank/rewards-catalog/');
            return data; // Возвращает список: скидки, бесплатное обслуживание и т.д.
        } catch (error) {
            console.error('Ошибка загрузки наград:', error);
            throw error;
        }
    },

    // 3. Обменять игровой уровень/достижение на реальную плюшку по карте
    // Тот самый пункт из ТЗ: "Как игровые успехи влияют на условия карты?"
    claimBankPerk: async (perkId) => {
        try {
            const data = await apiClient.post('/bank/claim-perk/', {
                perk_id: perkId
                // Пример: perkId = "free_service_1_month" (если город достиг 10 уровня)
            });
            return data;
        } catch (error) {
            console.error('Ошибка активации банковской услуги:', error);
            throw error;
        }
    }
};