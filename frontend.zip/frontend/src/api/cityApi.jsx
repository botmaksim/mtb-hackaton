import apiClient from './client';

export const cityApi = {
    // 1. Получить состояние города при входе
    // Ожидаем от Django массив зданий и текущий баланс
    getCityState: async () => {
        try {
            const data = await apiClient.get('/game/city/');
            return data;
        } catch (error) {
            console.error('Ошибка загрузки города:', error);
            throw error;
        }
    },

    // 2. Построить новое здание на сетке
    // Отправляем ID типа здания (например, "кофейня") и координаты X, Y
    buildBuilding: async (buildingTypeId, x, y) => {
        try {
            const data = await apiClient.post('/game/build/', {
                type_id: buildingTypeId,
                pos_x: x,
                pos_y: y,
            });
            return data; // Возвращает обновленный баланс и ID нового здания
        } catch (error) {
            console.error('Ошибка при постройке:', error);
            throw error;
        }
    },

    // 3. Собрать пассивный доход
    // На бэке Celery/математика посчитает сколько накапало и начислит
    collectIncome: async () => {
        try {
            const data = await apiClient.post('/game/collect/');
            return data; // Возвращает { collected_amount: 500, new_balance: 1500 }
        } catch (error) {
            console.error('Ошибка сбора прибыли:', error);
            throw error;
        }
    },

    // 4. Открыть промокейс (Гача)
    openCase: async (caseId) => {
        try {
            const data = await apiClient.post('/game/cases/open/', { case_id: caseId });
            return data; // Возвращает { drop_type: 'skin', drop_id: 12, drop_name: 'Золотая крыша' }
        } catch (error) {
            console.error('Ошибка открытия кейса:', error);
            throw error;
        }
    }
};