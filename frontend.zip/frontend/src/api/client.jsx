import axios from 'axios';

// Создаем базовый инстанс axios
const apiClient = axios.create({
    // Замените на URL вашего Django сервера (или используйте .env)
    baseURL: 'https://api.mtbank-game.by/api/v1',
    timeout: 10000, // Отвал по таймауту через 10 секунд
    headers: {
        'Content-Type': 'application/json',
    },
});

// ПЕРЕХВАТЧИК ЗАПРОСОВ (Request Interceptor)
// Срабатывает ПЕРЕД каждой отправкой запроса на бэкенд
apiClient.interceptors.request.use(
    (config) => {
        // Представим, что при входе через приложение МТБанка 
        // мы сохранили токен сессии в localStorage
        const token = localStorage.getItem('bank_game_token');

        if (token) {
            // Добавляем токен в заголовок Authorization (стандарт Django REST)
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// ПЕРЕХВАТЧИК ОТВЕТОВ (Response Interceptor)
// Срабатывает, когда Django возвращает нам ответ
apiClient.interceptors.response.use(
    (response) => {
        // Если всё ок, просто отдаем данные (отбрасывая лишнюю мету axios)
        return response.data;
    },
    (error) => {
        // Если бэкенд ответил 401 (Токен протух / Юзер не авторизован)
        if (error.response && error.response.status === 401) {
            console.warn('Токен истек. Перенаправление на авторизацию банка...');
            // Здесь можно вызвать логаут или редирект в WebView банка
            localStorage.removeItem('bank_game_token');
            window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

export default apiClient;